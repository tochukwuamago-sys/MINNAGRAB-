# MinnaGrab Project 1
Frontend prototype for a Minna-based multi-vendor delivery marketplace.
Open index.html in a browser.
